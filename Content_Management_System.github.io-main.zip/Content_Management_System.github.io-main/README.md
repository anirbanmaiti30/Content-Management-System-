# content_management_system
This is a web based Project.
In this website you can create new account and
can give your details which will be stored in the locally install server 
