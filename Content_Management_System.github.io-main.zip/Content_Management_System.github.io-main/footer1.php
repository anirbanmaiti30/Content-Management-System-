
        
            
            <div id="footer">
              <p>the &copy; reserved to Black Rebel.com</p>
            </div>
        </div>
    </body>
</html>