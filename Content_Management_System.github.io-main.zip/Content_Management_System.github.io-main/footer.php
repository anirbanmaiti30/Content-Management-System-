<div id="footer">
              <p>All the &copy; reserved to Black Rebel.com</p>
            </div>
        </div>
    </body>
</html>